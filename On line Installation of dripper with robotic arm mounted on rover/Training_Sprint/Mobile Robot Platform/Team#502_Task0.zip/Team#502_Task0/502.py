#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import Twist
import sys
  
  
def turtle_circle(radius):
    rospy.init_node('turtlesim', anonymous=True)
    pub = rospy.Publisher('/turtle1/cmd_vel', 
                          Twist, queue_size=10)
    rate = rospy.Rate(10)
    vel = Twist()
    now = rospy.Time.now()
    while rospy.Time.now() < now + rospy.Duration.from_sec(6.5):
        rospy.loginfo("Moving in a Circle")
        vel.linear.x = radius
        vel.linear.y = 0
        vel.linear.z = 0
        vel.angular.x = 0
        vel.angular.y = 0
        vel.angular.z = -1
       
        rospy.loginfo("Moving in a Circle")
        pub.publish(vel)
        rate.sleep()
     

    this = rospy.Time.now()
    while rospy.Time.now() < this + rospy.Duration.from_sec(5.5):
        vel.linear.x = radius
        vel.linear.y = 0
        vel.linear.z = 0
        vel.angular.x = 0
        vel.angular.y = 0
        vel.angular.z = 1
        rospy.loginfo("Radius = %f", 
                      radius)
        
        pub.publish(vel)
        rate.sleep()
    rospy.loginfo("Goal reached")
    
if __name__ == '__main__':
    try:
        turtle_circle(1)
    except rospy.ROSInterruptException:
        pass